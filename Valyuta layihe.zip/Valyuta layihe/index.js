let menuIcon=document.querySelector('#menu-icon')
let firstBoxItems=document.querySelectorAll('.container-1 .selection-box label')
let secondBoxItems=document.querySelectorAll('.container-2 .selection-box label')
let currenyFromParagraph=document.querySelector('.currency-from')
let currenyToParagraph=document.querySelector('.currency-to')
let output=document.getElementById('answer-output')
let inputArea=document.getElementById('user-input')
var currency1=document.getElementById('EUR1').value;
var currency2=document.getElementById('USD2').value;
eventListeners()
function eventListeners() {
  menuIcon.addEventListener('click',menu)
  inputArea.addEventListener("keyup", inputConvert);
  output.addEventListener("keyup", outputConvert);
}
firstBoxItems.forEach((item) => {
    item.addEventListener('click',(event)=>{
        currency1=event.target.innerText
        console.log(currency1)
        inputConvert()
    })
})
secondBoxItems.forEach((item) => {
    item.addEventListener('click',(event)=>{
        currency2=event.target.innerText
        console.log(currency2)
        outputConvert()
    })
})
function menu(){
        let nav=document.querySelector('#navbar ul')
        nav.classList.toggle('none')
    }
async function outputConvert() {
    const res = await fetch(`https://api.exchangerate.host/latest?base=${currency1}&symbols=${currency2}`);
    const data = await res.json();

    inputArea.value=(output.value/Object.values(data.rates)[0]).toFixed(3)
     
     currenyFromParagraph.innerHTML = `1 ${currency1} = ${Object.values(data.rates)[0].toFixed(2)} ${currency2}`;
     currenyToParagraph.innerHTML= `1 ${currency2} = ${(1/Object.values(data.rates)[0]).toFixed(5)} ${currency1}`;
  }
  async function inputConvert() {
    const res = await fetch(`https://api.exchangerate.host/latest?base=${currency1}&symbols=${currency2}`);
    const data = await res.json();
    
    output.value =(Object.values(data.rates)[0] * inputArea.value).toFixed(3);
     currenyFromParagraph.innerHTML = `1 ${currency1} = ${Object.values(data.rates)[0].toFixed(2)} ${currency2}`;
     currenyToParagraph.innerHTML= `1 ${currency2} = ${(1/Object.values(data.rates)[0]).toFixed(5)} ${currency1}`;

  }